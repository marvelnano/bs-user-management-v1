package com.example.bs_user_management_v1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BsUserManagementV1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
